create function gen_tokeninfo_tokenrefid(pretokenrefid text, numtokenrefid integer)
  returns text
language plpgsql
as $$
DECLARE
    tokenRefId TEXT := '00000000000';
    len INT := 11;
BEGIN
    tokenRefId := tokenRefId || numTokenRefId;
    preTokenRefId := preTokenRefId || SUBSTRING(tokenRefId, LENGTH(tokenRefId)-len, LENGTH(tokenRefId));
    RETURN preTokenRefId;
END
$$;

