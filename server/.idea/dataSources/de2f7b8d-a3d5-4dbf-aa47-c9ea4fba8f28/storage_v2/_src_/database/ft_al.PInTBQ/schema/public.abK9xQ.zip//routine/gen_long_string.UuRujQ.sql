create function gen_long_string(len integer)
  returns text
language plpgsql
as $$
DECLARE
    res TEXT := 'abcdefghijklmnopqrstuvwxyz';
BEGIN
    WHILE LENGTH(res) <= len
    LOOP
        res := res || res;
    END LOOP;

--     RETURN SUBSTRING(res, 1, len);
    RETURN SUBSTRING(res, 26-len, 26);
END
$$;

