create function return_int()
  returns integer
language plpgsql
as $$
BEGIN
  RETURN 1;
END
$$;

